Groove2Groove Dataset
=====================

Created by Ondrej Cifka  
LTCI, Telecom Paris, Institut Polytechnique de Paris

For more information, visit <https://groove2groove.telecom-paris.fr>.

This dataset contains synthetic accompaniments generated as described in the paper "Groove2Groove:
One-Shot Accompaniment Style Transfer with Supervision from Synthetic Data".

NOTE: This is only a small sample of the data, containing only 2 songs from the validation part.
The full dataset will be released (probably on Zenodo) once the paper is published.

The data may be used for non-commercial educational and research purposes only. If you use the
data in your work, please cite the paper as:
  
    % insert BibTeX once published

## Data description

### MIDI files
The `midi` directory contains one subdirectory for each part of the dataset:
- `train` contains 5744 MIDI files in 2872 styles (exactly 2 files per style). Each file contains
  252 measures (the RealBand maximum) following a 2 measure count-in.
- `val` and `test` each contain 1200 files in 40 styles (exactly 30 files per style, 16 bars per
  file after the count-in). The sets of styles are disjoint from each other and from those in
  `train`.
Each style is actually one of two substyles (meant for the A and B sections of a song) of a
Band-in-a-Box style. The two substyles are always in the same part of the dataset. More information
about the styles can be found in the file `styles.tsv`. The chord charts used to generate these
MIDI files are described in the next section.

Each set of MIDI files is provided in two versions, each in its own subdirectory:
- `raw` – the raw output of RealBand.
- `fixed` – non-empty files only, fixed so that each track has the correct program number.
The filenames have the form `{chart_name}.{style}_{substyle}.mid`. The `charts_styles_substyles.tsv`
file lists the chord chart filenames along with the styles and substyles applied to each chord
chart.

### Chord charts
The `charts/abc` and `charts/mgu` directories contain the corresponding chord charts in the ABC and
Band-in-a-Box (MGU) format, respectively. The MGU files are all in the default "ZZJAZZ" style; when
generating accompaniments, the correct style must be assigned first. To enable generation in the A
and B substyles, we provide each MGU file in an A and B variant where the entire chord chart is
just one long A or B section, respectively.

The chord charts were generated using language models trained on the iRb corpus (see the paper
for further details). 5/6 of the chord charts are in major keys, the other 1/6 in minor keys
(approximately following the distribution of keys in iRb).
